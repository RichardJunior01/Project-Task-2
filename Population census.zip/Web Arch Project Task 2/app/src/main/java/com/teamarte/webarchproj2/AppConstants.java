package com.teamarte.webarchproj2;

public class AppConstants {
    public static final String BASE_URL = "https://d14e3198.ngrok.io";

}
