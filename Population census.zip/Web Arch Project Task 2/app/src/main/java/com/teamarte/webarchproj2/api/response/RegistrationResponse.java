package com.teamarte.webarchproj2.api.response;

public class RegistrationResponse {
}
